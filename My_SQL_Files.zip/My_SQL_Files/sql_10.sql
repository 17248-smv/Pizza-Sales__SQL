SELECT pizza_size,
       ROUND(SUM(total_price), 2) AS Total_Sales,
       ROUND(SUM(total_price) * 100 / 
             (SELECT SUM(total_price) FROM pizza_sales WHERE QUARTER(STR_TO_DATE(order_date, '%Y-%m-%d')) = 1), 2) AS PCT
FROM pizza_sales
WHERE QUARTER(STR_TO_DATE(order_date, '%Y-%m-%d')) = 1
GROUP BY pizza_size;

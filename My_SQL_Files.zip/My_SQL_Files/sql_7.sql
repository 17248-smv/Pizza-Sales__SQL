SELECT DAYNAME(STR_TO_DATE(order_date, '%Y-%m-%d')) AS Order_Day,
COUNT(DISTINCT order_id) AS Total_Orders
FROM pizza_sales
GROUP BY DAYNAME(STR_TO_DATE(order_date, '%Y-%m-%d'));



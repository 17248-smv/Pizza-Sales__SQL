SELECT MONTHNAME(STR_TO_DATE(order_date, '%Y-%m-%d')) AS Order_Month,
COUNT(DISTINCT order_id) AS Total_Orders
FROM pizza_sales
GROUP BY order_month
ORDER BY FIELD(order_month, 
    'January', 'February', 'March', 'April', 'May', 'June', 
    'July', 'August', 'September', 'October', 'November', 'December');

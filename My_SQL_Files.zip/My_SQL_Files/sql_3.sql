select sum(total_price) / count(distinct order_id) as Avg_Order_Value
from pizza_sales;
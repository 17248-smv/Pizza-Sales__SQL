SELECT pizza_category,
       SUM(total_price) AS Total_Sales,
       SUM(total_price) * 100 / 
(SELECT SUM(total_price) FROM pizza_sales WHERE MONTH(STR_TO_DATE(order_date, '%Y-%m-%d')) = 1) AS PCT
FROM pizza_sales
WHERE MONTH(STR_TO_DATE(order_date, '%Y-%m-%d')) = 1
GROUP BY pizza_category;

select count(distinct order_id) as Total_Orders
from pizza_sales;
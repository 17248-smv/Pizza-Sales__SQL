select pizza_name, count(distinct order_id) as Total_Qrders
from pizza_sales
group by pizza_name
order by Total_Qrders 
limit 5;
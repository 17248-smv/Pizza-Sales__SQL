select * 
from pizza_sales;
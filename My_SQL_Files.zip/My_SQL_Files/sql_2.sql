select sum(total_price) as Total_Revenue
from pizza_sales;